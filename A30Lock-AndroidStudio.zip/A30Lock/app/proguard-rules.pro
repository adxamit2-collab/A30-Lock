# A30 Lock intentionally keeps its service and receiver names stable.
-keep class com.adxamit.a30lock.service.** { *; }
-keep class com.adxamit.a30lock.receiver.** { *; }
