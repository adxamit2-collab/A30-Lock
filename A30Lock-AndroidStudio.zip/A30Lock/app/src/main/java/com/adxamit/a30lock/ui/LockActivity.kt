package com.adxamit.a30lock.ui

import android.content.Intent
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.View
import android.widget.*
import androidx.biometric.BiometricPrompt
import androidx.biometric.BiometricManager
import androidx.core.content.ContextCompat
import com.adxamit.a30lock.R
import com.adxamit.a30lock.data.AppPrefs
import com.adxamit.a30lock.domain.LockStateManager
import com.adxamit.a30lock.security.PinManager

class LockActivity : BaseActivity() {
    private lateinit var pin: EditText; private var targetPackage:String?=null; private var fails=0; private var blockedUntil=0L
    override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContentView(R.layout.activity_lock);targetPackage=intent.getStringExtra("package");pin=findViewById(R.id.pin);findViewById<Button>(R.id.unlock).setOnClickListener{verify()};findViewById<Button>(R.id.fingerprint).setOnClickListener{biometric()}; bindKeys();findViewById<TextView>(R.id.appName).text=intent.getStringExtra("label")?:("A30 Lock")
        findViewById<View>(R.id.backspace).setOnClickListener{if(pin.text.isNotEmpty())pin.setText(pin.text.dropLast(1))}; val canBio=BiometricManager.from(this).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.BIOMETRIC_WEAK)==BiometricManager.BIOMETRIC_SUCCESS; if(!AppPrefs(this).fingerprintEnabled || !canBio)findViewById<Button>(R.id.fingerprint).visibility=View.GONE else biometric()
    }
    private fun verify(){if(System.currentTimeMillis()<blockedUntil){findViewById<TextView>(R.id.error).text="Temporarily locked. Try again in a few seconds.";return};val ok=PinManager(this).verify(pin.text.toString());if(ok){allowAndFinish()}else{fails++;pin.text.clear();if(fails>=5){blockedUntil=System.currentTimeMillis()+30_000;fails=0};findViewById<TextView>(R.id.error).text=if(blockedUntil>System.currentTimeMillis())"Too many attempts • 30s cooldown" else "Wrong PIN";vibrate()}}
    private fun bindKeys(){ listOf(1,2,3,4,5,6,7,8,9,0).forEach{n->findViewById<Button>(resources.getIdentifier("key$n","id",packageName)).setOnClickListener{if(pin.text.length<6)pin.append(n.toString())}};findViewById<Button>(R.id.keyClear).setOnClickListener{pin.text.clear()};findViewById<TextView>(R.id.backspace).setOnClickListener{if(pin.text.isNotEmpty())pin.setText(pin.text.dropLast(1))}}
    private fun allowAndFinish(){targetPackage?.let{LockStateManager(this).allow(it)};finish()}
    private fun vibrate(){if(!AppPrefs(this).vibrationEnabled)return; if(android.os.Build.VERSION.SDK_INT>=31)(getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator.vibrate(VibrationEffect.createOneShot(45,VibrationEffect.DEFAULT_AMPLITUDE)) else (getSystemService(VIBRATOR_SERVICE) as Vibrator).vibrate(45)}
    private fun biometric(){val executor=ContextCompat.getMainExecutor(this);val prompt=BiometricPrompt(this,executor,object:BiometricPrompt.AuthenticationCallback(){override fun onAuthenticationSucceeded(r:BiometricPrompt.AuthenticationResult){allowAndFinish()};override fun onAuthenticationFailed(){findViewById<TextView>(R.id.error).text="Fingerprint not recognized"}});val info=BiometricPrompt.PromptInfo.Builder().setTitle("A30 Lock").setSubtitle("Unlock ${targetPackage ?: "app"}").setNegativeButtonText("Use PIN").build();prompt.authenticate(info)}
}
