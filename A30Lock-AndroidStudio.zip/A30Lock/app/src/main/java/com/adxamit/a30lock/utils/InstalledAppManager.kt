package com.adxamit.a30lock.utils

import android.content.Context
import android.content.Intent
import android.graphics.drawable.Drawable

data class InstalledApp(val packageName: String, val label: String, val icon: Drawable)
class InstalledAppManager(private val context: Context) {
    fun load(): List<InstalledApp> {
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        return context.packageManager.queryIntentActivities(intent, 0).mapNotNull {
            val ai = it.activityInfo.applicationInfo
            if (ai.packageName == context.packageName) null else InstalledApp(ai.packageName, ai.loadLabel(context.packageManager).toString(), ai.loadIcon(context.packageManager))
        }.distinctBy { it.packageName }.sortedBy { it.label.lowercase() }
    }
}
