package com.adxamit.a30lock.data

import android.content.Context
import com.adxamit.a30lock.security.SecureStorage

class AppPrefs(context: Context) {
    private val store = SecureStorage(context)
    fun protectedPackages(): MutableSet<String> = store.get("protected_apps")?.split("|")?.filter { it.isNotBlank() }?.toMutableSet() ?: mutableSetOf()
    fun setProtectedPackages(value: Set<String>) = store.put("protected_apps", value.sorted().joinToString("|"))
    var fingerprintEnabled: Boolean
        get() = store.get("fingerprint") == "true"
        set(v) = store.put("fingerprint", v.toString())
    var vibrationEnabled: Boolean
        get() = store.get("vibration") != "false"
        set(v) = store.put("vibration", v.toString())
    var lockDelayMs: Long
        get() = store.get("lock_delay")?.toLongOrNull() ?: 0L
        set(v) = store.put("lock_delay", v.toString())
}
