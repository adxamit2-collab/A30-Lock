package com.adxamit.a30lock.ui

import android.os.Bundle
import android.widget.*
import androidx.biometric.BiometricManager
import com.adxamit.a30lock.R
import com.adxamit.a30lock.data.AppPrefs
import com.adxamit.a30lock.security.PinManager
import com.adxamit.a30lock.utils.PermissionUtils

class SettingsActivity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState); setContentView(R.layout.activity_settings); val p=AppPrefs(this)
        val fp=findViewById<Switch>(R.id.fp)
        val biometricAvailable = BiometricManager.from(this).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.BIOMETRIC_WEAK) == BiometricManager.BIOMETRIC_SUCCESS
        fp.isEnabled=biometricAvailable; fp.isChecked=p.fingerprintEnabled && biometricAvailable
        fp.setOnCheckedChangeListener{_,v->p.fingerprintEnabled=v}
        val vib=findViewById<Switch>(R.id.vib); vib.isChecked=p.vibrationEnabled; vib.setOnCheckedChangeListener{_,v->p.vibrationEnabled=v}
        findViewById<Spinner>(R.id.delay).apply{setSelection(if(p.lockDelayMs>=5000)1 else 0);onItemSelectedListener=object:AdapterView.OnItemSelectedListener{override fun onNothingSelected(parent:AdapterView<*>?){} override fun onItemSelected(parent:AdapterView<*>?,v:android.view.View?,pos:Int,id:Long){p.lockDelayMs=if(pos==1)5000 else 0}}}
        findViewById<Button>(R.id.changePin).setOnClickListener{ changePinDialog() }
        findViewById<Button>(R.id.service).setOnClickListener{startActivity(PermissionUtils.accessibilityIntent())}
        findViewById<TextView>(R.id.about).text="A30 Lock\nOffline App Lock • No ads • No analytics\nDesigned for low-RAM Samsung devices.\n\nAndroid limitation: A30 Lock cannot prevent its own uninstall or force-stop. Samsung/Android may stop accessibility services under aggressive battery optimization."
    }
    private fun changePinDialog(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;padding=24}
        val old=EditText(this).apply{hint="Current PIN";inputType=2 or 0x10}; val next=EditText(this).apply{hint="New 4–6 digit PIN";inputType=2 or 0x10}; val confirm=EditText(this).apply{hint="Confirm new PIN";inputType=2 or 0x10}
        box.addView(old);box.addView(next);box.addView(confirm)
        AlertDialog.Builder(this).setTitle("Change PIN").setView(box).setNegativeButton("Cancel",null).setPositiveButton("Save",null).create().also{d->d.setOnShowListener{d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener{val a=next.text.toString();val ok=PinManager(this).verify(old.text.toString())&&a.length in 4..6&&a.all(Char::isDigit)&&a==confirm.text.toString();if(ok){PinManager(this).setPin(a);d.dismiss();Toast.makeText(this,"PIN changed.",Toast.LENGTH_SHORT).show()}else Toast.makeText(this,"Check current PIN and new PIN.",Toast.LENGTH_SHORT).show()}};d.show()}
    }
}
