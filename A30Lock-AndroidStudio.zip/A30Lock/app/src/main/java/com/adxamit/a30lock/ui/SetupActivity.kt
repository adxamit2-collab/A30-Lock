package com.adxamit.a30lock.ui

import android.content.Intent
import android.os.Bundle
import android.widget.*
import com.adxamit.a30lock.R
import com.adxamit.a30lock.data.AppPrefs
import com.adxamit.a30lock.security.PinManager
import com.adxamit.a30lock.utils.PermissionUtils

class SetupActivity : BaseActivity() {
    private lateinit var pin: EditText; private lateinit var confirm: EditText
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContentView(R.layout.activity_setup)
        pin=findViewById(R.id.pin); confirm=findViewById(R.id.confirm); findViewById<Button>(R.id.create).setOnClickListener { create() }
    }
    private fun create() {
        val a=pin.text.toString(); val b=confirm.text.toString()
        if (a.length !in 4..6 || !a.all(Char::isDigit)) { pin.error="Use a 4–6 digit PIN"; return }
        if (a!=b) { confirm.error="PINs do not match"; return }
        PinManager(this).setPin(a)
        AppPrefs(this).fingerprintEnabled = false
        Toast.makeText(this,"PIN created securely.",Toast.LENGTH_SHORT).show()
        startActivity(Intent(this, MainActivity::class.java)); finish()
        if (!PermissionUtils.isAccessibilityEnabled(this)) startActivity(PermissionUtils.accessibilityIntent())
    }
}
