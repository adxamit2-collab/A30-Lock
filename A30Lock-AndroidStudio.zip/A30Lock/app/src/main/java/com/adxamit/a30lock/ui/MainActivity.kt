package com.adxamit.a30lock.ui

import android.content.Intent
import android.os.Bundle
import android.widget.*
import com.adxamit.a30lock.R
import com.adxamit.a30lock.data.AppPrefs
import com.adxamit.a30lock.security.PinManager
import com.adxamit.a30lock.utils.PermissionUtils

class MainActivity : BaseActivity() {
    private lateinit var status: TextView; private lateinit var count: TextView
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState)
        if (!PinManager(this).isConfigured()) { startActivity(Intent(this, SetupActivity::class.java)); finish(); return }
        setContentView(R.layout.activity_main)
        status=findViewById(R.id.status); count=findViewById(R.id.count)
        findViewById<Button>(R.id.manage).setOnClickListener { startActivity(Intent(this, AppListActivity::class.java)) }
        findViewById<Button>(R.id.settings).setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
        findViewById<View>(R.id.serviceCard).setOnClickListener { if(!PermissionUtils.isAccessibilityEnabled(this)) startActivity(PermissionUtils.accessibilityIntent()) }
    }
    override fun onResume(){ super.onResume(); val active=PermissionUtils.isAccessibilityEnabled(this); status.text=if(active)"● ACTIVE" else "● OFF"; status.setTextColor(getColor(if(active) R.color.red else R.color.muted)); count.text=AppPrefs(this).protectedPackages().size.toString() }
}
