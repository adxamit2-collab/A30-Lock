package com.adxamit.a30lock.security

import android.content.Context
import android.util.Base64
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

class PinManager(context: Context) {
    private val store = SecureStorage(context)
    fun isConfigured() = store.get("pin_hash") != null && store.get("pin_salt") != null
    fun setPin(pin: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        store.put("pin_salt", Base64.encodeToString(salt, Base64.NO_WRAP))
        store.put("pin_hash", hash(pin, salt))
    }
    fun verify(pin: String): Boolean = runCatching {
        val salt = Base64.decode(store.get("pin_salt"), Base64.NO_WRAP)
        hash(pin, salt) == store.get("pin_hash")
    }.getOrDefault(false)
    private fun hash(pin: String, salt: ByteArray): String {
        val spec = PBEKeySpec(pin.toCharArray(), salt, 120_000, 256)
        return Base64.encodeToString(SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded, Base64.NO_WRAP)
    }
}
