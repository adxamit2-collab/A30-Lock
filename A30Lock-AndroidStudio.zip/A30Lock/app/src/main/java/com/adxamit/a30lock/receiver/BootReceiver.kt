package com.adxamit.a30lock.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver:BroadcastReceiver(){override fun onReceive(context:Context,intent:Intent){/* AccessibilityService is restored by Android/Samsung when enabled. No background loop is started here. */}}
