package com.adxamit.a30lock.ui

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.*
import com.adxamit.a30lock.R
import com.adxamit.a30lock.data.AppPrefs
import com.adxamit.a30lock.utils.InstalledApp
import com.adxamit.a30lock.utils.InstalledAppManager

class AppListActivity : BaseActivity() {
    private val apps=mutableListOf<InstalledApp>(); private val filtered=mutableListOf<InstalledApp>(); private val checks=HashMap<String,Boolean>(); private lateinit var container: LinearLayout
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContentView(R.layout.activity_apps); container=findViewById(R.id.list); apps.addAll(InstalledAppManager(this).load()); val saved=AppPrefs(this).protectedPackages(); apps.forEach{checks[it.packageName]=saved.contains(it.packageName)}; render(apps)
        findViewById<EditText>(R.id.search).addTextChangedListener(object:TextWatcher{override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){} override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){render(apps.filter{it.label.contains(s.toString(),true)})} override fun afterTextChanged(e:Editable?) {}})
        findViewById<Button>(R.id.all).setOnClickListener{apps.forEach{checks[it.packageName]=true};render(apps)}; findViewById<Button>(R.id.clear).setOnClickListener{apps.forEach{checks[it.packageName]=false};render(apps)}
    }
    private fun render(list:List<InstalledApp>){filtered.clear();filtered.addAll(list);container.removeAllViews();list.forEach{app->val row=layoutInflater.inflate(R.layout.item_app,container,false);row.findViewById<ImageView>(R.id.icon).setImageDrawable(app.icon);row.findViewById<TextView>(R.id.name).text=app.label;val sw=row.findViewById<Switch>(R.id.toggle);sw.isChecked=checks[app.packageName]==true;sw.setOnCheckedChangeListener{_,v->checks[app.packageName]=v;save()};container.addView(row)}}
    private fun save(){AppPrefs(this).setProtectedPackages(checks.filterValues{it}.keys)}
}
