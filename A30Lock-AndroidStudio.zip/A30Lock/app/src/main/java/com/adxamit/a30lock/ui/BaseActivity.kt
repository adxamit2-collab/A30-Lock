package com.adxamit.a30lock.ui

import android.graphics.Color
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

open class BaseActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); window.statusBarColor = Color.BLACK; window.navigationBarColor = Color.BLACK }
}
