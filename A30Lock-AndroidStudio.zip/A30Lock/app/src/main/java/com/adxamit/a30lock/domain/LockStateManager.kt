package com.adxamit.a30lock.domain

import android.content.Context
import com.adxamit.a30lock.data.AppPrefs

class LockStateManager(context: Context) {
    private val prefs = AppPrefs(context)
    @Volatile private var foregroundPackage: String? = null
    @Volatile private var allowedPackage: String? = null
    @Volatile private var allowedUntil = 0L
    fun setForeground(pkg: String?) { if (pkg != foregroundPackage) { foregroundPackage = pkg; if (pkg != allowedPackage) allowedPackage = null } }
    fun shouldLock(pkg: String): Boolean {
        if (!prefs.protectedPackages().contains(pkg)) return false
        return !(allowedPackage == pkg && System.currentTimeMillis() < allowedUntil)
    }
    fun allow(pkg: String) { allowedPackage = pkg; allowedUntil = System.currentTimeMillis() + prefs.lockDelayMs.coerceAtLeast(800L) }
    fun resetForNewForeground(pkg: String) { if (pkg != foregroundPackage) setForeground(pkg) }
}
