package com.adxamit.a30lock.service

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import com.adxamit.a30lock.domain.LockStateManager
import com.adxamit.a30lock.utils.InstalledAppManager

class AppLockAccessibilityService : AccessibilityService() {
    private lateinit var state: LockStateManager
    override fun onServiceConnected(){super.onServiceConnected();state=LockStateManager(this)}
    override fun onAccessibilityEvent(event:AccessibilityEvent?){val pkg=event?.packageName?.toString()?:return;state.setForeground(pkg);if(state.shouldLock(pkg)){
        val label=runCatching{packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg,0)).toString()}.getOrDefault("Protected app")
        startActivity(Intent(this,com.adxamit.a30lock.ui.LockActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP).putExtra("package",pkg).putExtra("label",label))
    }}
    override fun onInterrupt() {}
}
