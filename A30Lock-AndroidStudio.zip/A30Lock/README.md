# A30 Lock

A native, offline-first Android App Lock for Samsung Galaxy A30s and similar Android devices.

## What it does
- Kotlin + XML, AndroidX, minSdk 23.
- Detects launchable installed apps and lets the user protect multiple apps.
- PIN is never stored as plaintext: a random salt + PBKDF2-HMAC-SHA256 hash is stored encrypted with an Android Keystore AES-GCM key.
- Fingerprint uses AndroidX BiometricPrompt; fingerprint data never enters this app.
- AccessibilityService detects foreground app transitions and opens the lock screen for protected apps.
- BootReceiver intentionally does not start a background loop; Android/Samsung restores the enabled accessibility service when permitted.
- No account, server, analytics, advertisements, contacts, messages, photos, screen recording, microphone, or network permission.

## Important Android limitation
A third-party app cannot reliably behave exactly like Samsung Secure Folder/App Lock. Android does not grant an ordinary app a guaranteed way to prevent its own uninstall/force-stop, and newer Android releases can restrict background activity launches. A30 Lock therefore uses the official AccessibilityService mechanism and clearly tells the user to enable it. Do not grant root, hidden APIs, or device-admin tricks to bypass these limits.

Accessibility is a powerful permission. A30 Lock sets `canRetrieveWindowContent=false` and only consumes window/package transition events. It does not inspect private content.

## Android Studio setup
1. Install Android Studio with Android SDK Platform 35 and a JDK 17 runtime.
2. Open this `A30Lock` folder in Android Studio.
3. Allow Gradle to download the build-time dependencies once. The installed app itself has no network permission and works offline.
4. Sync Gradle.
5. Build > Make Project.
6. Build > Build Bundle(s) / APK(s) > Build APK(s).

## Samsung Galaxy A30s setup
1. Install the APK.
2. Launch A30 Lock and create a 4–6 digit PIN.
3. When prompted, open Android Settings > Accessibility > Installed services > A30 Lock and enable it.
4. Return to A30 Lock; Protection should show ACTIVE.
5. Open Manage Protected Apps and enable the apps to protect.
6. If using fingerprint, enable Fingerprint unlock in A30 Lock and ensure a fingerprint is already enrolled in Samsung Settings.
7. For Samsung battery management, if the service stops, add A30 Lock to the device's battery optimization / sleeping-app exceptions where available. Menu names vary by One UI / Android version.

## Required permissions
- Accessibility Service: required for foreground app detection and lock triggering.
- RECEIVE_BOOT_COMPLETED: declared for reboot awareness; it does not run a permanent background service.
- USE_BIOMETRIC: used only for system biometric authentication.

Usage Access is NOT required by this implementation. The app does not request it.

## Troubleshooting
**Protection says OFF:** enable A30 Lock under Accessibility settings.

**Service stops after reboot:** confirm the accessibility service is still enabled and remove A30 Lock from Samsung's sleeping/deep-sleep list if your firmware offers that option.

**Fingerprint button missing:** the device must have supported biometric hardware and an enrolled fingerprint; otherwise use PIN.

**An app flashes before the lock:** Android/One UI versions can differ in how quickly an AccessibilityService receives a window event. Keep the service enabled and avoid aggressive battery restrictions. A third-party app cannot guarantee the same pre-launch interception timing as a system component.

**Cannot stop uninstall:** expected. Android does not allow a normal app to guarantee self-uninstall prevention.

## Build notes
Target SDK 35, min SDK 23. The project intentionally uses a small dependency set and no network permission.
