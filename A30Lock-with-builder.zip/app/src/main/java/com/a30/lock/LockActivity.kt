package com.a30.lock
import android.animation.ObjectAnimator
import android.graphics.Color
import android.os.*
import android.view.Gravity
import android.view.WindowManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat

class LockActivity : AppCompatActivity() {
    private var pin = ""; private var fails = 0; private var blocked = false
    private lateinit var dots: TextView; private var target = ""

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        target = intent.getStringExtra("pkg") ?: ""
        val label = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(target, 0)).toString() } catch (e: Exception) { "App" }
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(24), dp(24), dp(24), dp(24)) }
        col.addView(tv("🔒", 56f)); col.addView(tv(label, 22f)); 
        dots = tv("", 32f, RED).apply { gravity = Gravity.CENTER }; col.addView(dots)
        val keys = listOf("1","2","3","4","5","6","7","8","9","👆","0","⌫")
        for (r in 0 until 4) {
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER }
            for (c in 0 until 3) { val k = keys[r * 3 + c]
                row.addView(btn(k) { press(k) }, LinearLayout.LayoutParams(dp(80), dp(64)).apply { setMargins(dp(6), dp(6), dp(6), dp(6)) }) }
            col.addView(row)
        }
        val root = FrameLayout(this).apply { setBackgroundColor(BG); addView(WebBg(this@LockActivity)); addView(col) }
        setContentView(root); render()
        if (Store.bool(this, "fp", false)) bio()
    }
    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent); setIntent(intent); recreate()
    }
    private fun render() { dots.text = "●".repeat(pin.length).ifEmpty { " " } }
    private fun press(k: String) {
        if (blocked) return
        when (k) { "⌫" -> pin = pin.dropLast(1); "👆" -> bio(); else -> if (pin.length < 6) pin += k }
        render()
        if (pin.length >= 4 && Store.check(this, pin)) return ok()
        if (pin.length >= Store.pinLen(this)) wrong()
    }
    private fun wrong() {
        pin = ""; render(); fails++
        ObjectAnimator.ofFloat(dots, "translationX", 0f, 25f, -25f, 15f, -15f, 0f).setDuration(300).start()
        if (Store.bool(this, "vib", true)) @Suppress("DEPRECATION") (getSystemService(VIBRATOR_SERVICE) as? Vibrator)?.vibrate(120)
        if (fails >= 5) { blocked = true; fails = 0; Toast.makeText(this, "Too many attempts. Wait 30 s.", Toast.LENGTH_LONG).show()
            Handler(Looper.getMainLooper()).postDelayed({ blocked = false }, 30000) }
    }
    private fun ok() { LockService.open.add(target); LockService.current = target; LockService.instance?.hideOverlay(); finish() }
    private fun bio() {
        try {
            if (BiometricManager.from(this).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK) != BiometricManager.BIOMETRIC_SUCCESS) return
            BiometricPrompt(this, ContextCompat.getMainExecutor(this), object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(r: BiometricPrompt.AuthenticationResult) { ok() }
            }).authenticate(BiometricPrompt.PromptInfo.Builder().setTitle("A30 Lock").setNegativeButtonText("Use PIN")
                .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK).build())
        } catch (e: Exception) { }
    }
    @Deprecated("") override fun onBackPressed() {
        startActivity(android.content.Intent(android.content.Intent.ACTION_MAIN).addCategory(android.content.Intent.CATEGORY_HOME).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
        finish()
    }
}
