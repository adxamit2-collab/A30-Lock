package com.a30.lock
import android.content.Context
import android.provider.Settings
import android.util.Base64
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/** PIN is never stored: only a salted PBKDF2 hash in app-private storage (backup disabled). */
object Store {
    private fun p(c: Context) = c.getSharedPreferences("a30", Context.MODE_PRIVATE)
    private fun hash(pin: String, salt: ByteArray) =
        SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1").generateSecret(PBEKeySpec(pin.toCharArray(), salt, 10000, 256)).encoded
    fun hasPin(c: Context) = p(c).contains("h")
    fun setPin(c: Context, pin: String) {
        val s = ByteArray(16).also { SecureRandom().nextBytes(it) }
        p(c).edit().putString("s", Base64.encodeToString(s, 0)).putString("h", Base64.encodeToString(hash(pin, s), 0)).apply()
    }
    fun check(c: Context, pin: String): Boolean = try {
        val s = Base64.decode(p(c).getString("s", "")!!, 0)
        MessageDigest.isEqual(hash(pin, s), Base64.decode(p(c).getString("h", "")!!, 0))
    } catch (e: Exception) { false }
    fun locked(c: Context): Set<String> = HashSet(p(c).getStringSet("l", emptySet())!!)
    fun setLocked(c: Context, s: Set<String>) = p(c).edit().putStringSet("l", s).apply()
    fun bool(c: Context, k: String, d: Boolean) = p(c).getBoolean(k, d)
    fun setBool(c: Context, k: String, v: Boolean) = p(c).edit().putBoolean(k, v).apply()
    fun delay(c: Context) = p(c).getInt("delay", 0)
    fun setDelay(c: Context, v: Int) = p(c).edit().putInt("delay", v).apply()
    fun serviceOn(c: Context) = try {
        Settings.Secure.getString(c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?.contains(c.packageName + "/") == true
    } catch (e: Exception) { false }
}
