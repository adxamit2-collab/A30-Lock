package com.a30.lock
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager

class MainActivity : AppCompatActivity() {
    private lateinit var root: FrameLayout
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        root = FrameLayout(this).apply { setBackgroundColor(BG); addView(WebBg(this@MainActivity)) }
        setContentView(root)
    }
    override fun onResume() { super.onResume(); if (Store.hasPin(this)) home() else setup(false) }
    private fun show(v: View) { while (root.childCount > 1) root.removeViewAt(1); root.addView(ScrollView(this).apply { addView(v) }) }
    private fun col() = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL; setPadding(dp(24), dp(48), dp(24), dp(24)) }
    private fun fpAvailable() = try { BiometricManager.from(this).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK) == BiometricManager.BIOMETRIC_SUCCESS } catch (e: Exception) { false }
    private fun pinField(h: String) = EditText(this).apply { hint = h; setTextColor(-1); setHintTextColor(0xFF888888.toInt())
        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD; filters = arrayOf(android.text.InputFilter.LengthFilter(6)) }

    private fun setup(change: Boolean) {
        val c = col(); c.addView(tv(if (change) "New PIN" else "Create your PIN", 24f, RED)); c.addView(tv("4–6 digits", 14f, Color.GRAY))
        val a = pinField("PIN"); val b = pinField("Confirm PIN"); c.addView(a); c.addView(b)
        val fp = Switch(this).apply { text = "Use fingerprint"; setTextColor(-1); isChecked = fpAvailable(); isEnabled = fpAvailable() }; c.addView(fp)
        c.addView(btn("Save") {
            val p = a.text.toString()
            if (p.length !in 4..6) a.error = "Use 4–6 digits" else if (p != b.text.toString()) b.error = "PINs do not match"
            else { Store.setPin(this, p); Store.setBool(this, "fp", fp.isChecked); home() }
        })
        show(c)
    }
    private fun home() {
        val on = Store.serviceOn(this); val c = col()
        c.addView(tv("A30 LOCK", 30f, RED)); c.addView(tv("Protection", 14f, Color.GRAY))
        c.addView(tv(if (on) "● Protection: ACTIVE" else "● Protection: OFF", 20f, if (on) 0xFF3DDC84.toInt() else RED))
        if (!on) c.addView(tv("Protection is incomplete. Tap here to enable required permissions.", 14f, 0xFFFFB4B4.toInt()).apply { setOnClickListener { askAccessibility() } })
        c.addView(tv("\nProtected Apps: ${Store.locked(this).size}", 18f))
        c.addView(btn("Manage Protected Apps") { startActivity(Intent(this, AppListActivity::class.java)) })
        c.addView(tv("\nSecurity", 14f, Color.GRAY))
        c.addView(tv("Fingerprint   " + if (Store.bool(this, "fp", false)) "ON" else "OFF")); c.addView(tv("PIN   ●●●●"))
        c.addView(btn("Settings") { settings() })
        c.addView(btn("Samsung battery help") { battery() })
        show(c)
    }
    private fun askAccessibility() = AlertDialog.Builder(this).setTitle("Enable Accessibility")
        .setMessage("A30 Lock needs its Accessibility service only to see which app is opening, so it can ask for your PIN. It never reads screen content or sends data anywhere.\n\nOn the next screen choose Installed apps (or Downloaded apps) > A30 Lock > turn ON.")
        .setPositiveButton("Continue") { _, _ -> try { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } catch (e: Exception) { toast("Open Settings > Accessibility manually") } }
        .setNegativeButton("Cancel", null).show()
    private fun battery() = AlertDialog.Builder(this).setTitle("Keep protection running")
        .setMessage("Settings > Battery and device care > Battery > Background usage limits: remove A30 Lock from Sleeping/Deep sleeping apps and add it to Never sleeping apps. Also set A30 Lock to Unrestricted battery use.")
        .setPositiveButton("Open") { _, _ -> try { startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) } catch (e: Exception) { toast("Not available") } }
        .setNegativeButton("Close", null).show()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
    private fun settings() {
        val d = Store.delay(this)
        val items = arrayOf("Change PIN", "Fingerprint: " + (if (Store.bool(this, "fp", false)) "ON" else "OFF"),
            "Vibration: " + (if (Store.bool(this, "vib", true)) "ON" else "OFF"),
            "Relock: " + (if (d == 0) "immediately" else "after ${d}s"), "Theme: Dark", "Privacy", "About")
        AlertDialog.Builder(this).setTitle("Settings").setItems(items) { _, i ->
            when (i) {
                0 -> { val f = pinField("Current PIN"); AlertDialog.Builder(this).setTitle("Verify PIN").setView(f)
                    .setPositiveButton("OK") { _, _ -> if (Store.check(this, f.text.toString())) setup(true) else toast("Wrong PIN") }.show() }
                1 -> if (fpAvailable()) Store.setBool(this, "fp", !Store.bool(this, "fp", false)) else toast("Fingerprint not available/enrolled")
                2 -> Store.setBool(this, "vib", !Store.bool(this, "vib", true))
                3 -> Store.setDelay(this, if (d == 0) 30 else if (d == 30) 60 else 0)
                4 -> toast("Dark theme only")
                5 -> AlertDialog.Builder(this).setMessage("Fully offline. No accounts, analytics, ads or servers. Only the package name of the opened app is checked locally. PIN is stored only as a salted hash.").setPositiveButton("OK", null).show()
                6 -> toast("A30 Lock 1.0")
            }
            home()
        }.show()
    }
}
