package com.a30.lock
import android.content.Context
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.view.View
import android.widget.*

const val RED = 0xFFE5173F.toInt()
const val BG = 0xFF0A0A0C.toInt()
fun Context.dp(v: Int) = (v * resources.displayMetrics.density).toInt()
fun Context.tv(t: String, sz: Float = 16f, c: Int = Color.WHITE) = TextView(this).apply { text = t; textSize = sz; setTextColor(c) }
fun Context.btn(t: String, onClick: () -> Unit) = Button(this).apply {
    text = t; setTextColor(Color.WHITE); isAllCaps = false
    background = GradientDrawable().apply { cornerRadius = dp(16).toFloat(); setColor(0xFF1E1E24.toInt()); setStroke(dp(1), RED) }
    setOnClickListener { onClick() }
}

/** Decorative spider-web pattern (original geometric art, no logos). */
class WebBg(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x33E5173F; style = Paint.Style.STROKE; strokeWidth = 2f }
    override fun onDraw(cv: Canvas) {
        val cx = width / 2f; val cy = height * 0.3f
        for (i in 0 until 16) { val a = Math.PI * 2 * i / 16; cv.drawLine(cx, cy, cx + (Math.cos(a) * height).toFloat(), cy + (Math.sin(a) * height).toFloat(), p) }
        for (k in 1..7) cv.drawCircle(cx, cy, k * width / 6f, p)
    }
}
