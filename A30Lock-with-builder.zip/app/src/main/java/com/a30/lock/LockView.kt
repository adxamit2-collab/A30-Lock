package com.a30.lock
import android.animation.ObjectAnimator
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.Vibrator
import android.view.Gravity
import android.view.KeyEvent
import android.widget.FrameLayout
import android.widget.LinearLayout

/** PIN lock screen drawn as an overlay by the accessibility service (no background-activity limits). */
class LockView(private val c: Context, label: String, private val onOk: () -> Unit,
               private val onHome: () -> Unit, private val onFp: () -> Unit) : FrameLayout(c) {
    private var pin = ""; private var fails = 0; private var blocked = false
    private val dots = c.tv(" ", 32f, RED).apply { gravity = Gravity.CENTER }
    init {
        setBackgroundColor(BG)
        val col = LinearLayout(c).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(c.dp(24), c.dp(24), c.dp(24), c.dp(24)) }
        col.addView(c.tv("🔒", 56f)); col.addView(c.tv(label, 22f)); col.addView(dots)
        val keys = listOf("1","2","3","4","5","6","7","8","9","👆","0","⌫")
        for (r in 0 until 4) {
            val row = LinearLayout(c).apply { gravity = Gravity.CENTER }
            for (k in 0 until 3) { val key = keys[r * 3 + k]
                row.addView(c.btn(key) { press(key) }, LinearLayout.LayoutParams(c.dp(80), c.dp(64)).apply { setMargins(c.dp(6), c.dp(6), c.dp(6), c.dp(6)) }) }
            col.addView(row)
        }
        addView(WebBg(c)); addView(col)
        isFocusableInTouchMode = true; requestFocus()
    }
    private fun press(k: String) {
        if (blocked) return
        when (k) { "⌫" -> pin = pin.dropLast(1); "👆" -> onFp(); else -> if (pin.length < 6) pin += k }
        dots.text = "●".repeat(pin.length).ifEmpty { " " }
        if (pin.length >= 4 && Store.check(c, pin)) return onOk()
        if (pin.length >= Store.pinLen(c)) wrong()
    }
    private fun wrong() {
        pin = ""; dots.text = " "; fails++
        ObjectAnimator.ofFloat(dots, "translationX", 0f, 25f, -25f, 15f, -15f, 0f).setDuration(300).start()
        if (Store.bool(c, "vib", true)) @Suppress("DEPRECATION") (c.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator)?.vibrate(120)
        if (fails >= 5) { blocked = true; fails = 0
            Handler(Looper.getMainLooper()).postDelayed({ blocked = false }, 30000) }
    }
    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (e.keyCode == KeyEvent.KEYCODE_BACK) { if (e.action == KeyEvent.ACTION_UP) onHome(); return true }
        return super.dispatchKeyEvent(e)
    }
}
