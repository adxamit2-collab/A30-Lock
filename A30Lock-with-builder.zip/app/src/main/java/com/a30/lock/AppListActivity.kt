package com.a30.lock
import android.content.Intent
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class AppListActivity : AppCompatActivity() {
    data class A(val pkg: String, val name: String, val icon: Drawable)
    private var all = listOf<A>(); private var shown = listOf<A>()
    private lateinit var lv: ListView; private lateinit var search: EditText

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(BG); setPadding(dp(16), dp(24), dp(16), dp(8)) }
        search = EditText(this).apply { hint = "Search apps"; setTextColor(-1); setHintTextColor(0xFF888888.toInt()); isSingleLine = true
            addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { filter() }
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {} }) }
        val bar = LinearLayout(this)
        bar.addView(btn("Select All") { Store.setLocked(this, Store.locked(this) + shown.map { it.pkg }); refresh() }, LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(btn("Clear All") { Store.setLocked(this, emptySet()); refresh() }, LinearLayout.LayoutParams(0, -2, 1f))
        lv = ListView(this); lv.divider = null
        col.addView(tv("Protected Apps", 22f, RED)); col.addView(search); col.addView(bar); col.addView(lv)
        setContentView(col)
        Thread {
            try {
                val pm = packageManager
                val l = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
                    .map { A(it.activityInfo.packageName, it.loadLabel(pm).toString(), it.loadIcon(pm)) }
                    .filter { it.pkg != packageName }.distinctBy { it.pkg }.sortedBy { it.name.lowercase() }
                runOnUiThread { all = l; filter() }
            } catch (e: Exception) { runOnUiThread { Toast.makeText(this, "Could not load app list", Toast.LENGTH_LONG).show() } }
        }.start()
    }
    private fun filter() { val q = search.text.toString().trim().lowercase(); shown = all.filter { it.name.lowercase().contains(q) }; refresh() }
    private fun refresh() { lv.adapter = object : BaseAdapter() {
        val sel = Store.locked(this@AppListActivity)
        override fun getCount() = shown.size
        override fun getItem(i: Int) = shown[i]
        override fun getItemId(i: Int) = i.toLong()
        override fun getView(i: Int, v: View?, p: ViewGroup?): View {
            val a = shown[i]
            return LinearLayout(this@AppListActivity).apply {
                gravity = Gravity.CENTER_VERTICAL; setPadding(0, dp(6), 0, dp(6))
                addView(ImageView(context).apply { setImageDrawable(a.icon) }, LinearLayout.LayoutParams(dp(40), dp(40)))
                addView(tv(a.name).apply { setPadding(dp(12), 0, 0, 0) }, LinearLayout.LayoutParams(0, -2, 1f))
                addView(Switch(context).apply { isChecked = a.pkg in sel
                    setOnCheckedChangeListener { _, on -> Store.setLocked(context, Store.locked(context).let { if (on) it + a.pkg else it - a.pkg }) } })
            }
        } } }
}
