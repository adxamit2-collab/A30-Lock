package com.a30.lock
import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

/** Only reads the package name of the foreground window. No content, no network. */
class LockService : AccessibilityService() {
    companion object {
        val open = HashSet<String>()           // apps unlocked this session
        private val leftAt = HashMap<String, Long>()
        private var current: String? = null
        private val ignore = setOf("com.android.systemui", "com.samsung.android.honeyboard", "com.google.android.inputmethod.latin")
    }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        try {
            if (e?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
            val pkg = e.packageName?.toString() ?: return
            if (pkg == packageName || pkg in ignore || pkg == current) return
            val locked = Store.locked(this)
            val grace = Store.delay(this) * 1000L
            current?.let { old -> if (old in locked) { leftAt[old] = System.currentTimeMillis(); if (grace == 0L) open.remove(old) } }
            current = pkg
            if (pkg !in locked) return
            val ok = pkg in open && System.currentTimeMillis() - (leftAt[pkg] ?: 0L) < grace
            if (!ok) { open.remove(pkg)
                startActivity(Intent(this, LockActivity::class.java).putExtra("pkg", pkg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
        } catch (ex: Exception) { }
    }
    override fun onInterrupt() {}
}
