package com.a30.lock
import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.graphics.PixelFormat
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent

/** Only reads the package name of the foreground window. No content, no network. */
class LockService : AccessibilityService() {
    companion object {
        val open = HashSet<String>()           // apps unlocked this session
        val leftAt = HashMap<String, Long>()
        @Volatile var current: String? = null
        @Volatile var instance: LockService? = null
        private val ignore = setOf("com.android.systemui", "com.samsung.android.honeyboard", "com.google.android.inputmethod.latin",
            "com.vivo.input", "com.iqoo.secure")
    }
    private var overlay: View? = null
    private var lockedPkg: String? = null

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; hideOverlay(); return super.onUnbind(intent) }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        try {
            if (e?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
            val pkg = e.packageName?.toString() ?: return
            if (pkg == packageName || pkg in ignore) return
            if (overlay != null) { if (pkg == lockedPkg) return else hideOverlay() }
            if (pkg == current) return
            val locked = Store.locked(this)
            val grace = Store.delay(this) * 1000L
            val now = System.currentTimeMillis()
            current?.let { old -> if (old in locked) { leftAt[old] = now; if (grace == 0L) open.remove(old) } }
            current = pkg
            if (pkg !in locked) return
            val ok = pkg in open && grace > 0 && now - (leftAt[pkg] ?: 0L) < grace
            if (!ok) { open.remove(pkg); current = null; showOverlay(pkg) }
        } catch (ex: Exception) { }
    }

    private fun showOverlay(pkg: String) {
        if (overlay != null) return
        try {
            val label = try { packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString() } catch (x: Exception) { "App" }
            val v = LockView(this, label,
                { open.add(pkg); current = pkg; hideOverlay() },
                { performGlobalAction(GLOBAL_ACTION_HOME) },
                { try { startActivity(Intent(this, LockActivity::class.java).putExtra("pkg", pkg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (x: Exception) { } })
            val lp = WindowManager.LayoutParams(-1, -1, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_SECURE, PixelFormat.OPAQUE)
            (getSystemService(WINDOW_SERVICE) as WindowManager).addView(v, lp)
            overlay = v; lockedPkg = pkg
        } catch (ex: Exception) {
            try { startActivity(Intent(this, LockActivity::class.java).putExtra("pkg", pkg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            catch (x: Exception) { performGlobalAction(GLOBAL_ACTION_HOME) }
        }
    }

    fun hideOverlay() {
        overlay?.let { try { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } catch (x: Exception) { } }
        overlay = null; lockedPkg = null
    }
    override fun onInterrupt() {}
}
