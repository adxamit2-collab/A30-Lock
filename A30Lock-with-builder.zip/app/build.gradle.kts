plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.a30.lock"
    compileSdk = 34
    defaultConfig { applicationId = "com.a30.lock"; minSdk = 23; targetSdk = 33; versionCode = 1; versionName = "1.0" }
    buildTypes { release { isMinifyEnabled = true; proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt")) } }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_1_8; targetCompatibility = JavaVersion.VERSION_1_8 }
    kotlinOptions { jvmTarget = "1.8" }
}
dependencies {
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("androidx.biometric:biometric:1.1.0")
}
