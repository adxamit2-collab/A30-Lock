# A30 Lock
Open in Android Studio (Hedgehog+), let Gradle sync (needs internet once), Build > Build APK(s).
Enable: Accessibility > A30 Lock. Optional: battery "Never sleeping".
Limits: cannot block uninstall/disable; Android restarts enabled accessibility services after reboot by itself (no BootReceiver needed).
